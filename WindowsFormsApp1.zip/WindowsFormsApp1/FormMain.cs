﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
	public partial class FormMain : Form
	{
		int _number = 0;
		int _MAX = 0;
		bool brackets = false;
		bool _decimal = false;
		bool _add = false;
		bool _sub = false;
		bool _ride = false;
		bool _div = false;
		Random ran = new Random();
		StreamWriter sw = new StreamWriter("text.txt");
		public FormMain()
		{
			InitializeComponent();
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			_decimal = checkBox1.Checked;
		}

		private void checkBox2_CheckedChanged(object sender, EventArgs e)
		{
			brackets = checkBox2.Checked;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if(_number <= 0)
			{
				MessageBox.Show(this, "题目数量未输入或输入格式错误", "ERROR", MessageBoxButtons.OK);
				return;
            }
			if (_MAX <= 0)
			{
				MessageBox.Show(this, "最大值未输入或输入格式错误", "ERROR", MessageBoxButtons.OK);
				return;
			}
			_add = false;
			_sub = false;
			_ride = false;
			_div = false;
			foreach (object o in checkedListBox1.CheckedItems)
			{
				
				if (String.Compare(o.ToString(), "加法") == 0) _add = true;
				if (String.Compare(o.ToString(), "减法") == 0) _sub = true;
				if (String.Compare(o.ToString(), "乘法") == 0) _ride = true;
				if (String.Compare(o.ToString(), "除法") == 0) _div = true;
			}
			if (_add || _sub || _ride || _div)
			{
				for (int i = 0; i < _number; i++)
				{
					if(!_decimal) _create();
					else _create1();

				}
				MessageBox.Show(this, "生成成功", "结束", MessageBoxButtons.OK);
			}
			else
			{
				MessageBox.Show(this, "未选择运算符", "ERROR", MessageBoxButtons.OK);
			}
		}
		void _create()
		{
			int i = 0;
			int _brackets = 0;
			char[] a = new char[4];
			if (_add) a[i++] = '+';
			if (_sub) a[i++] = '-';
			if (_ride) a[i++] = '*';
			if (_div) a[i++] = '/';
			if (brackets)
			{
				_brackets = ran.Next(0, 3);
			}
			int num = ran.Next(1, _MAX);
			if (_brackets == 1) sw.Write('(');
			sw.Write(num);
			sw.Write(' ');
			num = ran.Next(0, i);
			sw.Write(a[num]);
			sw.Write(' ');
			num = ran.Next(1, _MAX);
			if (_brackets == 2) sw.Write('(');
			sw.Write(num);
			if (_brackets == 1) sw.Write(')');
			sw.Write(' ');
			num = ran.Next(0, i);
			sw.Write(a[num]);
			sw.Write(' ');
			num = ran.Next(1, _MAX);
			sw.Write(num);
			if (_brackets == 2) sw.Write(')');
			sw.WriteLine(" = ");
			sw.Flush();
		}

		void _create1()
		{
			_MAX *= 100;
			int i = 0;
			int _brackets = 0;
			char[] a = new char[4];
			if (_add) a[i++] = '+';
			if (_sub) a[i++] = '-';
			if (_ride) a[i++] = '*';
			if (_div) a[i++] = '/';
			if (brackets)
			{
				_brackets = ran.Next(0, 3);
			}
			int num = ran.Next(1, _MAX);
			double dnum = Convert.ToDouble(num) / 100;
			if (_brackets == 1) sw.Write('(');
			sw.Write(dnum);
			sw.Write(' ');
			num = ran.Next(0, i);
			sw.Write(a[num]);
			sw.Write(' ');
			num = ran.Next(1, _MAX);
			dnum = Convert.ToDouble(num) / 100;
			if (_brackets == 2) sw.Write('(');
			sw.Write(dnum);
			if (_brackets == 1) sw.Write(')');
			sw.Write(' ');
			num = ran.Next(0, i);
			sw.Write(a[num]);
			sw.Write(' ');
			num = ran.Next(1, _MAX);
			dnum = Convert.ToDouble(num) / 100;
			sw.Write(dnum);
			if (_brackets == 2) sw.Write(')');
			sw.WriteLine(" = ");
			sw.Flush();
		}

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
			_number = int.Parse(textBox1.Text);
		}

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
			_MAX = int.Parse(textBox2.Text);
		}
    }
}
